using Unity.MLAgents;
using Unity.MLAgents.Actuators;
using Unity.MLAgents.Sensors;
using UnityEngine;

public class AgentControllerMedium : Agent
{
    Vector3 startingPos;
    PlayerController playerController;
    GameObject opponent;

    float[] observations;
    float opponentVisible = 1;

    private void Start()
    {
        startingPos = transform.position;
        playerController = GetComponent<PlayerController>();
        opponent = playerController.opponent;
        observations = new float[4]; // Constant 5 for LowOb Agent

        print("activeate");
    }

    public override void OnEpisodeBegin()
    {
        transform.position = startingPos;
        playerController.bulletActive = false;
        Debug.Log("Episode Begin");
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        int moveX = actions.DiscreteActions[0] - 1;
        int moveZ = actions.DiscreteActions[1] - 1;
        int rotation = actions.DiscreteActions[2] - 1;
        int shoot = actions.DiscreteActions[3];

        playerController.Move(new Vector2(moveX, moveZ));
        playerController.Rotate(rotation);
        if (shoot == 1) { playerController.Shoot(); }



        Debug.Log(moveX + " " + moveZ + " " + rotation + " " + shoot);
    }

    public override void CollectObservations(VectorSensor sensor)
    {
        float heading = Vector2.Angle(new Vector2(transform.position.x, transform.position.z), new Vector2(opponent.transform.position.x, opponent.transform.position.z));
        float canShoot = playerController.bulletActive ? 0 : 1;
        float distance = Vector3.Distance(transform.position, opponent.transform.position);
        float opponentVisible = 1;
        float bulletVisible = opponent.GetComponent<PlayerController>().bulletActive ? 0 : 1;
        Vector3 bulletLocation = opponent.GetComponent<PlayerController>().bullet.transform.position;
        float bulletHeading = Vector2.Angle(new Vector2(transform.position.x, transform.position.z), new Vector2(opponent.transform.position.x, opponent.transform.position.z));

        sensor.AddObservation(heading);
        sensor.AddObservation(canShoot);
        sensor.AddObservation(distance);
        sensor.AddObservation(opponentVisible);
        sensor.AddObservation(bulletVisible);
        sensor.AddObservation(bulletLocation);
        sensor.AddObservation(bulletHeading);
    }

    public void hitOpponent()
    {
        SetReward(1f);
        EndEpisode();
    }
}
