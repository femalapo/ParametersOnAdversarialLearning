using UnityEngine;

public class Bullet : MonoBehaviour
{
    public GameObject owner;
    public GameObject opponent;
    public Rigidbody rb;
    public float speed;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.linearVelocity = transform.forward * speed;
    }

    private void OnTriggerEnter(Collider other)
    {
        owner.GetComponent<PlayerController>().bulletActive = false;

        if(other.gameObject == opponent)
        { 
            print("Opponent hit.");
            AgentControllerLow agentController = owner.GetComponent<AgentControllerLow>();
            if(agentController != null)
            {
                agentController.hitOpponent();
            }
        }

        Destroy(gameObject);
    }
}
